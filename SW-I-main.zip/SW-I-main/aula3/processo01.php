<?php
   $nome = $_GET['cxnome'];

   echo "Bem vindo, $nome";

?>