<?php
$nome = $_POST['nome'];
$mensagem = $_POST['mensagem'];

echo "<h2> Nome: </h2>" . $_POST['nome'] ;
echo "<h2> Mensagem: </h2> " . $_POST['mensagem'];
?>

